extends Node
## Carrito de compras (global).

signal changed

const FREE_SHIPPING_OVER := 250000
const SHIPPING_FEE := 12000

var items: Array = []  # {pid, option, qty}


## Devuelve "" si todo salió bien, o un mensaje para mostrar.
func add(pid: int, option: String, qty: int = 1) -> String:
	var p: Dictionary = Database.get_product(pid)
	if p.is_empty() or not p.active:
		return "Este producto ya no está disponible"
	var stock: int = Database.stock_of(p, option)
	if stock <= 0:
		return "Producto agotado en esta opción"
	for it in items:
		if it.pid == pid and it.option == option:
			if it.qty + qty > stock:
				it.qty = stock
				changed.emit()
				return "Solo hay %d unidades disponibles" % stock
			it.qty += qty
			changed.emit()
			return ""
	var msg := ""
	if qty > stock:
		qty = stock
		msg = "Solo hay %d unidades disponibles" % stock
	items.append({"pid": pid, "option": option, "qty": qty})
	changed.emit()
	return msg


func set_qty(pid: int, option: String, qty: int) -> String:
	for it in items:
		if it.pid == pid and it.option == option:
			var p: Dictionary = Database.get_product(pid)
			var stock: int = Database.stock_of(p, option) if not p.is_empty() else 0
			var msg := ""
			if qty > stock:
				qty = stock
				msg = "Solo hay %d unidades disponibles" % stock
			if qty <= 0:
				remove(pid, option)
				return msg
			it.qty = qty
			changed.emit()
			return msg
	return ""


func remove(pid: int, option: String) -> void:
	for i in range(items.size()):
		if items[i].pid == pid and items[i].option == option:
			items.remove_at(i)
			break
	changed.emit()


func clear() -> void:
	items.clear()
	changed.emit()


func count() -> int:
	var n := 0
	for it in items:
		n += int(it.qty)
	return n


## Líneas enriquecidas con datos actuales del producto (descarta los que ya no existen).
func lines() -> Array:
	var out: Array = []
	var keep: Array = []
	for it in items:
		var p: Dictionary = Database.get_product(int(it.pid))
		if p.is_empty() or not p.active:
			continue
		var stock: int = Database.stock_of(p, str(it.option))
		if stock <= 0:
			continue
		if it.qty > stock:
			it.qty = stock
		keep.append(it)
		out.append({
			"pid": int(it.pid),
			"name": p.name,
			"option": it.option,
			"option_label": p.option_label,
			"qty": int(it.qty),
			"price": int(p.price),
			"total": int(p.price) * int(it.qty),
			"stock": stock,
			"product": p,
		})
	items = keep
	return out


func subtotal() -> int:
	var s := 0
	for l in lines():
		s += int(l.total)
	return s


func shipping_for(sub: int) -> int:
	if sub <= 0 or sub >= FREE_SHIPPING_OVER:
		return 0
	return SHIPPING_FEE


func total() -> int:
	var s: int = subtotal()
	return s + shipping_for(s)
