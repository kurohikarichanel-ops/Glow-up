extends Control
## Glow Up - tienda pública. Toda la interfaz se construye por código y se adapta
## al ancho de la ventana (celular / tablet / computador).

const PAYMENTS := ["Pago contra entrega", "Transferencia bancaria", "Nequi / Daviplata"]

var view := "store"
var view_arg: Variant = null
var filter_cat := "Todo"
var search_text := ""
var sort_mode := 0
var price_cap := 0
var only_available := true
var admin_ok := false
var admin_tab := 0
var _fails := 0
var _lock_until := 0.0
var _co := {"name": "", "phone": "", "email": "", "city": "", "address": "", "notes": "", "payment": 0}

var _header_holder: PanelContainer
var _scroll: ScrollContainer
var _content: VBoxContainer
var _cart_btn: Button
var _last_w := 0.0
var _resize_timer: Timer


func _ready() -> void:
	theme = UI.make_theme()
	var bg := ColorRect.new()
	bg.color = UI.CREAM
	add_child(bg)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 0)
	add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_header_holder = PanelContainer.new()
	_header_holder.add_theme_stylebox_override("panel", UI.style(UI.WHITE, 0, UI.LINE, 0, 0, 0))
	root.add_child(_header_holder)
	_scroll = ScrollContainer.new()
	_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(_scroll)
	_content = VBoxContainer.new()
	_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_scroll.add_child(_content)
	_resize_timer = Timer.new()
	_resize_timer.one_shot = true
	_resize_timer.wait_time = 0.12
	_resize_timer.timeout.connect(_on_resized_settled)
	add_child(_resize_timer)
	resized.connect(_on_resized)
	Database.data_changed.connect(_on_data_changed)
	Cart.changed.connect(_on_cart_changed)
	await get_tree().process_frame
	_last_w = size.x
	_build_header()
	_render()


# ---------------------------------------------------------------- layout helpers

func _compact() -> bool:
	return size.x < 720.0


func _pad() -> int:
	if _compact():
		return 14
	return int(maxf(24.0, (size.x - 1240.0) / 2.0))


func _cols() -> int:
	if _compact():
		return 2
	return clampi(int((size.x - 2.0 * _pad()) / 270.0), 2, 5)


func _clear(n: Node) -> void:
	for c in n.get_children():
		n.remove_child(c)
		c.queue_free()


func _on_resized() -> void:
	if _resize_timer != null and is_inside_tree():
		_resize_timer.start()


func _on_resized_settled() -> void:
	if absf(size.x - _last_w) < 1.0:
		return
	_last_w = size.x
	_build_header()
	_render(true)


func _on_data_changed() -> void:
	_render(view == "admin")


func _on_cart_changed() -> void:
	_update_badge()
	if view == "cart":
		_render(true)


func _go(v: String, arg: Variant = null) -> void:
	view = v
	view_arg = arg
	_render()


func _update_badge() -> void:
	if _cart_btn != null and is_instance_valid(_cart_btn):
		var n: int = Cart.count()
		_cart_btn.text = "Carrito" if n == 0 else "Carrito (%d)" % n


# ---------------------------------------------------------------- encabezado

func _build_header() -> void:
	_clear(_header_holder)
	var m := MarginContainer.new()
	var pad := _pad()
	m.add_theme_constant_override("margin_left", pad)
	m.add_theme_constant_override("margin_right", pad)
	m.add_theme_constant_override("margin_top", 10)
	m.add_theme_constant_override("margin_bottom", 10)
	_header_holder.add_child(m)

	var logo := Button.new()
	logo.text = "GLOW UP"
	logo.flat = true
	logo.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	logo.add_theme_font_size_override("font_size", 26)
	for k in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		logo.add_theme_color_override(k, UI.ROSE_DARK)
	logo.pressed.connect(_on_logo)

	var search := LineEdit.new()
	search.placeholder_text = "Buscar vestidos, tenis, labiales..."
	search.text = search_text
	search.clear_button_enabled = true
	search.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	search.text_changed.connect(_on_search)

	_cart_btn = UI.button("", true)
	_cart_btn.pressed.connect(_go.bind("cart"))
	_update_badge()

	if _compact():
		var v := UI.vbox(8)
		var row := UI.hbox(8)
		logo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		logo.alignment = HORIZONTAL_ALIGNMENT_LEFT
		row.add_child(logo)
		row.add_child(_cart_btn)
		v.add_child(row)
		v.add_child(search)
		m.add_child(v)
	else:
		var h := UI.hbox(18)
		h.add_child(logo)
		h.add_child(search)
		h.add_child(_cart_btn)
		m.add_child(h)


func _on_logo() -> void:
	filter_cat = "Todo"
	search_text = ""
	_build_header()
	_go("store")


func _on_search(t: String) -> void:
	search_text = t
	if view != "store":
		view = "store"
		view_arg = null
	_render()


# ---------------------------------------------------------------- render principal

func _render(keep_scroll: bool = false) -> void:
	if _content == null:
		return
	var sv: int = _scroll.scroll_vertical
	_clear(_content)
	var m := MarginContainer.new()
	var pad := _pad()
	m.add_theme_constant_override("margin_left", pad)
	m.add_theme_constant_override("margin_right", pad)
	m.add_theme_constant_override("margin_top", 18)
	m.add_theme_constant_override("margin_bottom", 24)
	m.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_content.add_child(m)
	var page := UI.vbox(16)
	page.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	m.add_child(page)
	match view:
		"store": _view_store(page)
		"product": _view_product(page)
		"cart": _view_cart(page)
		"checkout": _view_checkout(page)
		"done": _view_done(page)
		"login": _view_login(page)
		"admin": _view_admin(page)
	_footer(page)
	if keep_scroll:
		await get_tree().process_frame
		_scroll.scroll_vertical = sv
	else:
		_scroll.scroll_vertical = 0


func _footer(page: VBoxContainer) -> void:
	page.add_child(UI.spacer(10))
	page.add_child(UI.hr())
	var row := HFlowContainer.new()
	row.add_theme_constant_override("h_separation", 16)
	row.add_child(UI.label("Glow Up - ropa, zapatos, accesorios y maquillaje.", 14, UI.MUTED))
	row.add_child(UI.label("Envíos a toda Colombia. Gratis desde %s." % Util.cop(Cart.FREE_SHIPPING_OVER), 14, UI.MUTED))
	var adm := UI.button("Administración")
	adm.flat = true
	adm.pressed.connect(_go.bind("admin" if admin_ok else "login"))
	row.add_child(adm)
	page.add_child(row)


# ---------------------------------------------------------------- tienda / catálogo

func _filtered() -> Array:
	var out: Array = []
	var q: String = search_text.strip_edges().to_lower()
	for p in Database.products:
		if not p.active:
			continue
		if filter_cat != "Todo" and p.category != filter_cat:
			continue
		if price_cap > 0 and int(p.price) > price_cap:
			continue
		if only_available and Database.total_stock(p) <= 0:
			continue
		if q != "":
			var hay: String = (str(p.name) + " " + str(p.brand) + " " + str(p.category) + " " + str(p.description)).to_lower()
			if not hay.contains(q):
				continue
		out.append(p)
	if sort_mode == 1:
		out.sort_custom(func(a, b): return int(a.price) < int(b.price))
	elif sort_mode == 2:
		out.sort_custom(func(a, b): return int(a.price) > int(b.price))
	elif sort_mode == 3:
		out.sort_custom(func(a, b): return str(a.name) < str(b.name))
	else:
		out.sort_custom(_sort_featured)
	return out


func _sort_featured(a: Dictionary, b: Dictionary) -> bool:
	if a.featured != b.featured:
		return a.featured
	return int(a.id) > int(b.id)


func _card_width() -> float:
	var avail: float = size.x - 2.0 * _pad()
	var c: int = _cols()
	return (avail - 14.0 * float(c - 1)) / float(c)


func _view_store(page: VBoxContainer) -> void:
	if search_text == "" and filter_cat == "Todo":
		page.add_child(_hero())
	page.add_child(_filters())
	var items: Array = _filtered()
	page.add_child(UI.label("%d productos" % items.size(), 14, UI.MUTED))
	if items.is_empty():
		var c := UI.card(24)
		var v := UI.vbox(10)
		v.add_child(UI.label("No encontramos productos con esos filtros", 20, UI.INK, true, true))
		v.add_child(UI.label("Prueba con otra búsqueda o quita algún filtro.", 15, UI.MUTED, false, true))
		var b := UI.button("Quitar filtros", true)
		b.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
		b.pressed.connect(_clear_filters)
		v.add_child(b)
		c.add_child(v)
		page.add_child(c)
		return
	var grid := GridContainer.new()
	grid.columns = _cols()
	grid.add_theme_constant_override("h_separation", 14)
	grid.add_theme_constant_override("v_separation", 14)
	var w: float = _card_width()
	for p in items:
		grid.add_child(_product_card(p, w))
	page.add_child(grid)


func _clear_filters() -> void:
	filter_cat = "Todo"
	search_text = ""
	price_cap = 0
	only_available = true
	_build_header()
	_render()


func _hero() -> Control:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UI.style(Color("#F3D3D9"), 20, UI.CLEAR, 0, 26, 26))
	var v := UI.vbox(8)
	v.add_child(UI.label("NUEVA COLECCIÓN", 13, UI.GOLD, true))
	v.add_child(UI.label("Tu estilo, tu momento", 34 if not _compact() else 28, UI.INK, true, true))
	v.add_child(UI.label("Ropa, zapatos, accesorios y maquillaje para brillar todos los días. Envío gratis desde %s." % Util.cop(Cart.FREE_SHIPPING_OVER), 16, UI.MUTED, false, true))
	p.add_child(v)
	return p


func _filters() -> Control:
	var v := UI.vbox(10)
	var chips := HFlowContainer.new()
	chips.add_theme_constant_override("h_separation", 8)
	chips.add_theme_constant_override("v_separation", 8)
	var cats: Array = ["Todo"]
	cats.append_array(Database.CATEGORIES)
	for c in cats:
		var b := UI.chip(c, c == filter_cat)
		b.pressed.connect(_set_cat.bind(c))
		chips.add_child(b)
	v.add_child(chips)
	var row := HFlowContainer.new()
	row.add_theme_constant_override("h_separation", 10)
	row.add_theme_constant_override("v_separation", 8)
	var sort := OptionButton.new()
	for s in ["Destacados", "Precio: menor a mayor", "Precio: mayor a menor", "Nombre A-Z"]:
		sort.add_item(s)
	sort.selected = sort_mode
	sort.item_selected.connect(_on_sort)
	row.add_child(sort)
	var price := OptionButton.new()
	var caps := [0, 100000, 200000, 300000]
	for c in caps:
		price.add_item("Cualquier precio" if c == 0 else "Hasta %s" % Util.cop(c))
	price.selected = caps.find(price_cap) if caps.has(price_cap) else 0
	price.item_selected.connect(func(i: int): price_cap = caps[i]; _render())
	row.add_child(price)
	var cb := CheckBox.new()
	cb.text = "Solo disponibles"
	cb.button_pressed = only_available
	cb.toggled.connect(func(on: bool): only_available = on; _render())
	row.add_child(cb)
	v.add_child(row)
	return v


func _set_cat(c: String) -> void:
	filter_cat = c
	_render()


func _on_sort(i: int) -> void:
	sort_mode = i
	_render()


func _product_card(p: Dictionary, w: float) -> Control:
	var card := PanelContainer.new()
	card.add_theme_stylebox_override("panel", UI.style(UI.WHITE, 14, UI.LINE, 1, 0, 0))
	card.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	card.clip_contents = true
	var v := UI.vbox(0)
	var img := ProductImage.new()
	img.custom_minimum_size = Vector2(0, w * 1.2)
	v.add_child(img)
	img.setup(p.images, p.category, str(p.id))
	var m := MarginContainer.new()
	for s in ["left", "right"]:
		m.add_theme_constant_override("margin_" + s, 12)
	m.add_theme_constant_override("margin_top", 10)
	m.add_theme_constant_override("margin_bottom", 12)
	var info := UI.vbox(3)
	info.add_child(UI.label(str(p.category).to_upper(), 11, UI.GOLD, true))
	info.add_child(UI.label(p.name, 15, UI.INK, true, true))
	info.add_child(UI.label(Util.cop(p.price), 16, UI.ROSE_DARK, true))
	var stock: int = Database.total_stock(p)
	if stock <= 0:
		info.add_child(UI.label("Agotado", 13, UI.DANGER))
	elif stock <= 3:
		info.add_child(UI.label("Últimas unidades", 13, UI.WARN))
	m.add_child(info)
	v.add_child(m)
	card.add_child(v)
	UI.ignore_mouse(v)
	var pid: int = int(p.id)
	card.gui_input.connect(func(e: InputEvent):
		if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT and not e.pressed:
			_go("product", pid))
	return card


# ---------------------------------------------------------------- detalle de producto

func _view_product(page: VBoxContainer) -> void:
	var back := UI.button("< Volver al catálogo")
	back.flat = true
	back.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	back.pressed.connect(_go.bind("store"))
	page.add_child(back)
	var p: Dictionary = Database.get_product(int(view_arg))
	if p.is_empty() or not p.active:
		page.add_child(UI.label("Este producto ya no está disponible.", 20, UI.INK, true))
		return
	var layout: BoxContainer
	if _compact():
		layout = VBoxContainer.new()
	else:
		layout = HBoxContainer.new()
	layout.add_theme_constant_override("separation", 28)
	page.add_child(layout)

	# --- galería
	var gallery := UI.vbox(10)
	gallery.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	gallery.size_flags_stretch_ratio = 1.0
	var avail: float = size.x - 2.0 * _pad()
	var gw: float = avail if _compact() else (avail - 28.0) / 2.0
	var main_img := ProductImage.new()
	main_img.custom_minimum_size = Vector2(0, minf(gw * 1.15, 680.0))
	gallery.add_child(main_img)
	main_img.setup(p.images, p.category, str(p.id))
	if p.images.size() > 1:
		var th := HBoxContainer.new()
		th.add_theme_constant_override("separation", 8)
		for i in range(p.images.size()):
			var t := ProductImage.new()
			t.custom_minimum_size = Vector2(72, 72)
			t.mouse_filter = Control.MOUSE_FILTER_STOP
			t.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
			th.add_child(t)
			var rot: Array = p.images.slice(i)
			rot.append_array(p.images.slice(0, i))
			t.setup(rot, p.category, str(p.id))
			t.gui_input.connect(func(e: InputEvent):
				if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT and not e.pressed:
					main_img.setup(rot, p.category, str(p.id)))
		gallery.add_child(th)
	layout.add_child(gallery)

	# --- información
	var info := UI.vbox(10)
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info.size_flags_stretch_ratio = 1.0
	info.add_child(UI.label(str(p.category).to_upper(), 13, UI.GOLD, true))
	info.add_child(UI.label(p.name, 30 if not _compact() else 25, UI.INK, true, true))
	if str(p.brand) != "":
		info.add_child(UI.label("Marca: " + str(p.brand), 15, UI.MUTED))
	info.add_child(UI.label(Util.cop(p.price), 28, UI.ROSE_DARK, true))
	var stock_lbl := UI.label("", 14, UI.OK)
	info.add_child(stock_lbl)

	var sel := {"opt": "", "qty": 1}
	var opt_name_lbl := UI.label("", 15, UI.MUTED)
	var qty_lbl := UI.label("1", 18, UI.INK, true)
	var has_opts: bool = str(p.option_label) != ""
	if not has_opts and p.options.size() > 0:
		sel.opt = p.options[0].name
	var refresh_stock := func():
		var n: int = Database.stock_of(p, sel.opt) if sel.opt != "" else Database.total_stock(p)
		if n <= 0:
			stock_lbl.text = "Agotado"
			stock_lbl.add_theme_color_override("font_color", UI.DANGER)
		elif n <= 5:
			stock_lbl.text = "Quedan %d unidades" % n
			stock_lbl.add_theme_color_override("font_color", UI.WARN)
		else:
			stock_lbl.text = "Disponible"
			stock_lbl.add_theme_color_override("font_color", UI.OK)
	refresh_stock.call()

	if has_opts:
		info.add_child(UI.spacer(4))
		info.add_child(UI.label("Selecciona tu %s" % str(p.option_label).to_lower(), 16, UI.INK, true))
		var flow := HFlowContainer.new()
		flow.add_theme_constant_override("h_separation", 8)
		flow.add_theme_constant_override("v_separation", 8)
		var group := ButtonGroup.new()
		var is_tone: bool = str(p.option_label) == "Tono"
		for o in p.options:
			var b := Button.new()
			b.toggle_mode = true
			b.button_group = group
			b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
			var out_of: bool = int(o.stock) <= 0
			if is_tone and str(o.color) != "":
				b.custom_minimum_size = Vector2(44, 44)
				b.tooltip_text = str(o.name) + (" (agotado)" if out_of else "")
				var col := Color(str(o.color))
				if out_of:
					col = col.lerp(Color.WHITE, 0.6)
				b.add_theme_stylebox_override("normal", UI.style(col, 22, UI.LINE, 1, 0, 0))
				b.add_theme_stylebox_override("hover", UI.style(col, 22, UI.GOLD, 2, 0, 0))
				b.add_theme_stylebox_override("pressed", UI.style(col, 22, UI.INK, 3, 0, 0))
				b.add_theme_stylebox_override("disabled", UI.style(col, 22, UI.LINE, 1, 0, 0))
			else:
				b.text = str(o.name) + (" (agotado)" if out_of else "")
				b.custom_minimum_size = Vector2(52, 44)
			b.disabled = out_of
			var oname: String = str(o.name)
			b.pressed.connect(func():
				sel.opt = oname
				sel.qty = 1
				qty_lbl.text = "1"
				opt_name_lbl.text = "%s: %s" % [p.option_label, oname]
				refresh_stock.call())
			flow.add_child(b)
		info.add_child(flow)
		info.add_child(opt_name_lbl)

	# cantidad
	var qrow := UI.hbox(12)
	qrow.add_child(UI.label("Cantidad", 16, UI.INK, true))
	var minus := UI.button("-")
	var plus := UI.button("+")
	minus.custom_minimum_size = Vector2(44, 44)
	plus.custom_minimum_size = Vector2(44, 44)
	minus.pressed.connect(func():
		sel.qty = maxi(1, int(sel.qty) - 1)
		qty_lbl.text = str(sel.qty))
	plus.pressed.connect(func():
		var mx: int = Database.stock_of(p, sel.opt) if sel.opt != "" else 10
		sel.qty = mini(maxi(mx, 1), int(sel.qty) + 1)
		qty_lbl.text = str(sel.qty))
	qrow.add_child(minus)
	qty_lbl.custom_minimum_size = Vector2(28, 0)
	qty_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	qrow.add_child(qty_lbl)
	qrow.add_child(plus)
	info.add_child(qrow)

	var btns := HFlowContainer.new()
	btns.add_theme_constant_override("h_separation", 10)
	btns.add_theme_constant_override("v_separation", 10)
	var add := UI.button("Agregar al carrito", true)
	var buy := UI.button("Comprar ahora")
	var pid: int = int(p.id)
	var label_txt: String = str(p.option_label).to_lower()
	var do_add := func(go_cart: bool):
		if has_opts and sel.opt == "":
			UI.toast("Selecciona tu %s" % label_txt)
			return
		var msg: String = Cart.add(pid, sel.opt, int(sel.qty))
		if msg != "" and Database.stock_of(p, sel.opt) <= 0:
			UI.toast(msg)
			return
		if go_cart:
			_go("cart")
		else:
			UI.toast(msg if msg != "" else "Agregado al carrito")
	add.pressed.connect(func(): do_add.call(false))
	buy.pressed.connect(func(): do_add.call(true))
	if Database.total_stock(p) <= 0:
		add.disabled = true
		buy.disabled = true
	btns.add_child(add)
	btns.add_child(buy)
	info.add_child(btns)

	# ficha
	info.add_child(UI.spacer(6))
	var fc := UI.card(18)
	var fv := UI.vbox(8)
	fv.add_child(UI.label("Descripción", 18, UI.INK, true))
	fv.add_child(UI.label(p.description, 15, UI.MUTED, false, true))
	if p.details.size() > 0:
		fv.add_child(UI.spacer(4))
		fv.add_child(UI.label("Detalles del producto", 18, UI.INK, true))
		for d in p.details:
			fv.add_child(UI.label("- " + str(d), 15, UI.MUTED, false, true))
	fv.add_child(UI.spacer(4))
	fv.add_child(UI.label("Ficha técnica", 18, UI.INK, true))
	for row in [["Marca", p.brand], ["Categoría", p.category], ["Referencia", p.sku]]:
		if str(row[1]) != "":
			var r := UI.hbox(8)
			var k := UI.label(str(row[0]), 14, UI.MUTED)
			k.custom_minimum_size.x = 100
			r.add_child(k)
			r.add_child(UI.label(str(row[1]), 14, UI.INK, false, true))
			fv.add_child(r)
	fv.add_child(UI.label("Envío a toda Colombia. Gratis en compras desde %s." % Util.cop(Cart.FREE_SHIPPING_OVER), 14, UI.MUTED, false, true))
	fc.add_child(fv)
	info.add_child(fc)
	layout.add_child(info)

	# relacionados
	var related: Array = []
	for q in Database.products:
		if q.active and q.category == p.category and int(q.id) != int(p.id):
			related.append(q)
	if related.size() > 0:
		page.add_child(UI.spacer(8))
		page.add_child(UI.label("También te puede gustar", 22, UI.INK, true))
		var grid := GridContainer.new()
		var rc: int = mini(_cols(), 4)
		grid.columns = rc
		grid.add_theme_constant_override("h_separation", 14)
		grid.add_theme_constant_override("v_separation", 14)
		var rw: float = (avail - 14.0 * float(rc - 1)) / float(rc)
		for i in range(mini(rc, related.size())):
			grid.add_child(_product_card(related[i], rw))
		page.add_child(grid)


# ---------------------------------------------------------------- carrito

func _view_cart(page: VBoxContainer) -> void:
	page.add_child(UI.label("Tu carrito", 30, UI.INK, true))
	var lines: Array = Cart.lines()
	if lines.is_empty():
		var c := UI.card(28)
		var v := UI.vbox(10)
		v.add_child(UI.label("Tu carrito está vacío", 20, UI.INK, true))
		v.add_child(UI.label("Explora el catálogo y agrega tus favoritos.", 15, UI.MUTED, false, true))
		var b := UI.button("Ir a la tienda", true)
		b.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
		b.pressed.connect(_go.bind("store"))
		v.add_child(b)
		c.add_child(v)
		page.add_child(c)
		return
	var layout: BoxContainer
	if _compact():
		layout = VBoxContainer.new()
	else:
		layout = HBoxContainer.new()
	layout.add_theme_constant_override("separation", 16)
	var list := UI.vbox(10)
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for l in lines:
		list.add_child(_cart_row(l))
	layout.add_child(list)
	var summary := _summary_card(lines, true)
	if not _compact():
		summary.custom_minimum_size.x = 340
		summary.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	layout.add_child(summary)
	page.add_child(layout)


func _cart_row(l: Dictionary) -> Control:
	var card := UI.card(12)
	var h := UI.hbox(12)
	var img := ProductImage.new()
	img.custom_minimum_size = Vector2(84, 104)
	h.add_child(img)
	img.setup(l.product.images, l.product.category, str(l.pid))
	var v := UI.vbox(4)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_child(UI.label(l.name, 16, UI.INK, true, true))
	if str(l.option_label) != "":
		v.add_child(UI.label("%s: %s" % [l.option_label, l.option], 14, UI.MUTED))
	v.add_child(UI.label(Util.cop(l.price), 14, UI.MUTED))
	var row := HFlowContainer.new()
	row.add_theme_constant_override("h_separation", 8)
	var minus := UI.button("-")
	var plus := UI.button("+")
	minus.custom_minimum_size = Vector2(40, 40)
	plus.custom_minimum_size = Vector2(40, 40)
	var pid: int = int(l.pid)
	var opt: String = str(l.option)
	var qty: int = int(l.qty)
	minus.pressed.connect(func(): _cart_qty(pid, opt, qty - 1))
	plus.pressed.connect(func(): _cart_qty(pid, opt, qty + 1))
	row.add_child(minus)
	var ql := UI.label(str(qty), 17, UI.INK, true)
	ql.custom_minimum_size = Vector2(26, 0)
	ql.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	row.add_child(ql)
	row.add_child(plus)
	var tot := UI.label(Util.cop(l.total), 16, UI.ROSE_DARK, true)
	row.add_child(tot)
	var rm := UI.button("Quitar", false, true)
	rm.flat = true
	rm.pressed.connect(func(): Cart.remove(pid, opt))
	row.add_child(rm)
	v.add_child(row)
	h.add_child(v)
	card.add_child(h)
	return card


func _cart_qty(pid: int, opt: String, q: int) -> void:
	var msg: String = Cart.set_qty(pid, opt, q)
	if msg != "":
		UI.toast(msg)


func _summary_card(lines: Array, with_buttons: bool) -> PanelContainer:
	var sub := 0
	for l in lines:
		sub += int(l.total)
	var ship: int = Cart.shipping_for(sub)
	var c := UI.card(18)
	var v := UI.vbox(10)
	v.add_child(UI.label("Resumen del pedido", 20, UI.INK, true))
	v.add_child(_kv("Subtotal", Util.cop(sub)))
	v.add_child(_kv("Envío", "Gratis" if ship == 0 else Util.cop(ship)))
	if ship > 0:
		v.add_child(UI.label("Te faltan %s para envío gratis." % Util.cop(Cart.FREE_SHIPPING_OVER - sub), 13, UI.GOLD, false, true))
	v.add_child(UI.hr())
	var t := _kv("Total", Util.cop(sub + ship))
	for ch in t.get_children():
		if ch is Label:
			(ch as Label).add_theme_font_size_override("font_size", 20)
	v.add_child(t)
	if with_buttons:
		var go := UI.button("Finalizar pedido", true)
		go.pressed.connect(_go.bind("checkout"))
		v.add_child(go)
		var more := UI.button("Seguir comprando")
		more.pressed.connect(_go.bind("store"))
		v.add_child(more)
	c.add_child(v)
	return c


func _kv(k: String, val: String) -> HBoxContainer:
	var h := UI.hbox(8)
	var a := UI.label(k, 16, UI.MUTED)
	a.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(a)
	var b := UI.label(val, 16, UI.INK, true)
	b.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	h.add_child(b)
	return h


# ---------------------------------------------------------------- checkout

func _view_checkout(page: VBoxContainer) -> void:
	page.add_child(UI.label("Finalizar pedido", 30, UI.INK, true))
	var lines: Array = Cart.lines()
	if lines.is_empty():
		page.add_child(UI.label("Tu carrito está vacío.", 18, UI.MUTED))
		var b := UI.button("Ir a la tienda", true)
		b.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
		b.pressed.connect(_go.bind("store"))
		page.add_child(b)
		return
	var layout: BoxContainer
	if _compact():
		layout = VBoxContainer.new()
	else:
		layout = HBoxContainer.new()
	layout.add_theme_constant_override("separation", 16)
	var form := UI.card(20)
	form.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var fv := UI.vbox(10)
	fv.add_child(UI.label("Datos de entrega", 20, UI.INK, true))
	for f in [["name", "Nombre completo"], ["phone", "Teléfono / WhatsApp"], ["email", "Correo electrónico"], ["city", "Ciudad"], ["address", "Dirección de entrega"], ["notes", "Notas (opcional)"]]:
		var key: String = f[0]
		fv.add_child(UI.label(f[1], 14, UI.MUTED))
		var le := LineEdit.new()
		le.text = str(_co[key])
		le.text_changed.connect(func(t: String): _co[key] = t)
		fv.add_child(le)
	fv.add_child(UI.label("Método de pago", 14, UI.MUTED))
	var pay := OptionButton.new()
	for p in PAYMENTS:
		pay.add_item(p)
	pay.selected = int(_co.payment)
	pay.item_selected.connect(func(i: int): _co.payment = i)
	fv.add_child(pay)
	var err := UI.label("", 14, UI.DANGER, false, true)
	fv.add_child(err)
	var confirm := UI.button("Confirmar pedido", true)
	confirm.pressed.connect(_place_order.bind(err))
	fv.add_child(confirm)
	var back := UI.button("Volver al carrito")
	back.pressed.connect(_go.bind("cart"))
	fv.add_child(back)
	form.add_child(fv)
	layout.add_child(form)
	var summary := _summary_card(lines, false)
	if not _compact():
		summary.custom_minimum_size.x = 340
		summary.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	var sv: VBoxContainer = summary.get_child(0)
	sv.add_child(UI.hr())
	for l in lines:
		var txt: String = "%d x %s" % [l.qty, l.name]
		if str(l.option_label) != "":
			txt += " (%s)" % l.option
		sv.add_child(UI.label(txt, 13, UI.MUTED, false, true))
	layout.add_child(summary)
	page.add_child(layout)


func _validate_checkout() -> String:
	if str(_co.name).strip_edges().length() < 3:
		return "Escribe tu nombre completo."
	var digits := ""
	for ch in str(_co.phone):
		if ch >= "0" and ch <= "9":
			digits += ch
	if digits.length() < 7:
		return "Escribe un teléfono válido."
	var em: String = str(_co.email).strip_edges()
	if not (em.contains("@") and em.contains(".")):
		return "Escribe un correo electrónico válido."
	if str(_co.city).strip_edges().length() < 2:
		return "Escribe tu ciudad."
	if str(_co.address).strip_edges().length() < 6:
		return "Escribe tu dirección de entrega."
	return ""


func _place_order(err: Label) -> void:
	var e: String = _validate_checkout()
	if e != "":
		err.text = e
		return
	var lines: Array = []
	for l in Cart.lines():
		lines.append({"pid": l.pid, "option": l.option, "qty": l.qty})
	var customer := {
		"name": str(_co.name).strip_edges(),
		"phone": str(_co.phone).strip_edges(),
		"email": str(_co.email).strip_edges(),
		"city": str(_co.city).strip_edges(),
		"address": str(_co.address).strip_edges(),
		"notes": str(_co.notes).strip_edges(),
	}
	var res: Dictionary = Database.create_order(customer, lines, PAYMENTS[int(_co.payment)], "Tienda online", "Pendiente")
	if not res.ok:
		err.text = str(res.error)
		return
	Cart.clear()
	_go("done", int(res.order.id))


func _view_done(page: VBoxContainer) -> void:
	var o: Dictionary = Database.get_order(int(view_arg))
	var c := UI.card(26)
	var v := UI.vbox(10)
	v.add_child(UI.label("¡Gracias por tu pedido!", 30, UI.ROSE_DARK, true, true))
	if o.is_empty():
		v.add_child(UI.label("Tu pedido fue registrado.", 16, UI.MUTED, false, true))
	else:
		v.add_child(UI.label("Pedido #%d  -  %s" % [o.id, o.date], 16, UI.INK, true, true))
		for it in o["items"]:
			var t: String = "%d x %s" % [it.qty, it.name]
			if str(it.option) != "Única":
				t += " (%s)" % it.option
			v.add_child(_kv(t, Util.cop(int(it.price) * int(it.qty))))
		v.add_child(_kv("Envío", "Gratis" if int(o.shipping) == 0 else Util.cop(o.shipping)))
		v.add_child(UI.hr())
		v.add_child(_kv("Total", Util.cop(o.total)))
		v.add_child(UI.label("Método de pago: %s. Estado: %s." % [o.payment, o.status], 15, UI.MUTED, false, true))
		v.add_child(UI.label("Nos pondremos en contacto contigo al teléfono %s para confirmar la entrega." % o.customer.phone, 15, UI.MUTED, false, true))
	var b := UI.button("Seguir comprando", true)
	b.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	b.pressed.connect(_go.bind("store"))
	v.add_child(b)
	c.add_child(v)
	page.add_child(c)


# ---------------------------------------------------------------- administración

func _view_login(page: VBoxContainer) -> void:
	var holder := CenterContainer.new()
	var c := UI.card(24)
	c.custom_minimum_size.x = minf(420.0, size.x - 2.0 * _pad())
	var v := UI.vbox(10)
	v.add_child(UI.label("Administración", 26, UI.INK, true))
	v.add_child(UI.label("Ingresa la contraseña para gestionar la tienda.", 15, UI.MUTED, false, true))
	var pw := LineEdit.new()
	pw.secret = true
	pw.placeholder_text = "Contraseña"
	v.add_child(pw)
	var err := UI.label("", 14, UI.DANGER, false, true)
	v.add_child(err)
	var go := UI.button("Entrar", true)
	var attempt := func():
		var now: float = Time.get_unix_time_from_system()
		if now < _lock_until:
			err.text = "Demasiados intentos. Espera %d segundos." % int(_lock_until - now)
			return
		if Database.verify_admin(pw.text):
			_fails = 0
			admin_ok = true
			_go("admin")
		else:
			_fails += 1
			pw.text = ""
			if _fails >= 5:
				_lock_until = now + 30.0
				_fails = 0
				err.text = "Demasiados intentos. Espera 30 segundos."
			else:
				err.text = "Contraseña incorrecta."
	go.pressed.connect(attempt)
	pw.text_submitted.connect(func(_t: String): attempt.call())
	v.add_child(go)
	var back := UI.button("Volver a la tienda")
	back.flat = true
	back.pressed.connect(_go.bind("store"))
	v.add_child(back)
	c.add_child(v)
	holder.add_child(c)
	page.add_child(holder)


func _view_admin(page: VBoxContainer) -> void:
	if not admin_ok:
		_view_login(page)
		return
	var panel := AdminPanel.new()
	panel.tab_index = admin_tab
	panel.exit_admin.connect(_go.bind("store"))
	panel.logout.connect(_on_logout)
	panel.tab_changed_index.connect(func(i: int): admin_tab = i)
	page.add_child(panel)
	panel.build(_compact())


func _on_logout() -> void:
	admin_ok = false
	_go("store")
