extends Node
## Base de datos de Glow Up: productos, inventario, pedidos y ventas.
## - Guarda todo en user://glowup_db.json (local, persistente).
## - Opcional: sincroniza con una base remota compartida (URL REST con GET/PUT de un JSON)
##   para que varios dispositivos vean los mismos productos, inventario y pedidos.

signal data_changed
signal sync_status(msg: String)

const SAVE_PATH := "user://glowup_db.json"
const IMG_DIR := "user://images"
const CATEGORIES := ["Ropa", "Zapatos", "Accesorios", "Maquillaje"]
const STATUSES := ["Pendiente", "Confirmado", "Enviado", "Entregado", "Cancelado"]
const SALT := "glowup-v1-"
const DEFAULT_PASSWORD := "glowup2026"
const LOW_STOCK := 5


# Fotografías de producto (URLs directas de Unsplash).
# Se cargan desde ProductImage y se conservan como parte de los datos de ejemplo.
const PRODUCT_IMAGES := {
	"GU-RP-001": "https://images.unsplash.com/photo-1539008835657-9e8e9680c956?auto=format&fit=crop&w=800&q=85",
	"GU-RP-002": "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=800&q=85",
	"GU-RP-003": "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=800&q=85",
	"GU-RP-004": "https://images.unsplash.com/photo-1551163943-3f6a855d1153?auto=format&fit=crop&w=800&q=85",
	"GU-ZP-001": "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=85",
	"GU-ZP-002": "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=800&q=85",
	"GU-ZP-003": "https://images.unsplash.com/photo-1608256246200-53e635b5b65f?auto=format&fit=crop&w=800&q=85",
	"GU-AC-001": "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=85",
	"GU-AC-002": "https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=800&q=85",
	"GU-AC-003": "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=800&q=85",
	"GU-MQ-001": "https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&w=800&q=85",
	"GU-MQ-002": "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=800&q=85",
	"GU-MQ-003": "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=800&q=85",
	"GU-MQ-004": "https://images.unsplash.com/photo-1512496015851-a90fb38ba796?auto=format&fit=crop&w=800&q=85"
}

var products: Array = []
var orders: Array = []
var settings: Dictionary = {}
var updated: int = 0
var sync_msg := "Base de datos local"

var _push_req: HTTPRequest
var _pull_req: HTTPRequest
var _push_pending := false


func _ready() -> void:
	DirAccess.make_dir_recursive_absolute(IMG_DIR)
	_load()
	_push_req = HTTPRequest.new()
	_push_req.timeout = 15.0
	add_child(_push_req)
	_push_req.request_completed.connect(_on_push_done)
	_pull_req = HTTPRequest.new()
	_pull_req.timeout = 15.0
	add_child(_pull_req)
	_pull_req.request_completed.connect(_on_pull_done)
	var t := Timer.new()
	t.wait_time = 20.0
	t.autostart = true
	t.timeout.connect(pull)
	add_child(t)
	pull()


# ---------------------------------------------------------------- persistencia

func _default_settings() -> Dictionary:
	return {
		"admin_hash": hash_password(DEFAULT_PASSWORD),
		"remote_url": "",
		"remote_header": "",
	}


func hash_password(pw: String) -> String:
	return (SALT + pw).sha256_text()


func _load() -> void:
	settings = _default_settings()
	var fresh := not FileAccess.file_exists(SAVE_PATH)
	if not fresh:
		var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
		if f != null:
			var d: Variant = JSON.parse_string(f.get_as_text())
			if typeof(d) == TYPE_DICTIONARY:
				products = d.get("products", [])
				orders = d.get("orders", [])
				updated = int(d.get("updated", 0))
				var s: Dictionary = d.get("settings", {})
				for k in s:
					settings[k] = s[k]
	_normalize()
	if fresh:
		_seed()
		_write_local()


func _normalize() -> void:
	for p in products:
		p["id"] = int(p.get("id", 0))
		p["price"] = int(p.get("price", 0))
		p["active"] = bool(p.get("active", true))
		p["featured"] = bool(p.get("featured", false))
		p["details"] = p.get("details", [])
		p["images"] = p.get("images", [])
		p["sku"] = str(p.get("sku", ""))
		p["brand"] = str(p.get("brand", ""))
		p["description"] = str(p.get("description", ""))
		p["option_label"] = str(p.get("option_label", ""))
		var opts: Array = p.get("options", [])
		for o in opts:
			o["stock"] = int(o.get("stock", 0))
			o["color"] = str(o.get("color", ""))
		p["options"] = opts
	for o in orders:
		o["id"] = int(o.get("id", 0))
		o["total"] = int(o.get("total", 0))
		o["subtotal"] = int(o.get("subtotal", 0))
		o["shipping"] = int(o.get("shipping", 0))
		o["ts"] = int(o.get("ts", 0))
		for it in o["items"]:
			it["pid"] = int(it.get("pid", 0))
			it["qty"] = int(it.get("qty", 0))
			it["price"] = int(it.get("price", 0))


func _remote_doc() -> Dictionary:
	return {"products": products, "orders": orders, "updated": updated}


func _write_local() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f == null:
		return
	var d := _remote_doc()
	d["settings"] = settings
	f.store_string(JSON.stringify(d, "\t"))


func save() -> void:
	updated = int(Time.get_unix_time_from_system())
	_write_local()
	_push_remote()


func export_path() -> String:
	return ProjectSettings.globalize_path(SAVE_PATH)


# ---------------------------------------------------------------- sincronización remota

func _remote_headers() -> PackedStringArray:
	var h := PackedStringArray(["Content-Type: application/json"])
	var extra: String = str(settings.get("remote_header", "")).strip_edges()
	if extra != "":
		h.append(extra)
	return h


func has_remote() -> bool:
	return str(settings.get("remote_url", "")).strip_edges() != ""


func pull() -> void:
	if not has_remote():
		return
	if _pull_req.get_http_client_status() != HTTPClient.STATUS_DISCONNECTED:
		return
	_pull_req.request(str(settings.remote_url), _remote_headers(), HTTPClient.METHOD_GET)


func _push_remote() -> void:
	if not has_remote():
		return
	if _push_req.get_http_client_status() != HTTPClient.STATUS_DISCONNECTED:
		_push_pending = true
		return
	_push_req.request(str(settings.remote_url), _remote_headers(), HTTPClient.METHOD_PUT, JSON.stringify(_remote_doc()))


func _set_sync(msg: String) -> void:
	sync_msg = msg
	sync_status.emit(msg)


func _on_push_done(result: int, code: int, _h: PackedStringArray, _b: PackedByteArray) -> void:
	if result == HTTPRequest.RESULT_SUCCESS and code >= 200 and code < 300:
		_set_sync("Sincronizado con la base remota")
	else:
		_set_sync("No se pudo enviar a la base remota (código %d)" % code)
	if _push_pending:
		_push_pending = false
		_push_remote()


func _on_pull_done(result: int, code: int, _h: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or code < 200 or code >= 300:
		_set_sync("Sin conexión con la base remota")
		return
	var d: Variant = JSON.parse_string(body.get_string_from_utf8())
	if typeof(d) == TYPE_DICTIONARY and d.has("record"):
		d = d["record"]
	if typeof(d) != TYPE_DICTIONARY or not d.has("products"):
		_push_remote()  # remoto vacío: se inicializa con los datos locales
		return
	var ru: int = int(d.get("updated", 0))
	if ru > updated:
		products = d["products"]
		orders = d.get("orders", [])
		updated = ru
		_normalize()
		_write_local()
		_set_sync("Sincronizado con la base remota")
		data_changed.emit()
	elif ru < updated:
		_push_remote()
	else:
		_set_sync("Sincronizado con la base remota")


# ---------------------------------------------------------------- productos

func get_product(id: int) -> Dictionary:
	for p in products:
		if int(p.id) == id:
			return p
	return {}


func next_product_id() -> int:
	var m := 0
	for p in products:
		m = maxi(m, int(p.id))
	return m + 1


func upsert_product(p: Dictionary) -> void:
	if int(p.get("id", 0)) <= 0:
		p["id"] = next_product_id()
	for i in range(products.size()):
		if int(products[i].id) == int(p.id):
			products[i] = p
			save()
			data_changed.emit()
			return
	products.append(p)
	save()
	data_changed.emit()


func delete_product(id: int) -> void:
	for i in range(products.size()):
		if int(products[i].id) == id:
			products.remove_at(i)
			break
	save()
	data_changed.emit()


func stock_of(p: Dictionary, option: String) -> int:
	if p.is_empty():
		return 0
	for o in p.options:
		if o.name == option:
			return int(o.stock)
	return 0


func total_stock(p: Dictionary) -> int:
	var n := 0
	for o in p.options:
		n += int(o.stock)
	return n


func set_stock(pid: int, option: String, qty: int, notify: bool = true) -> void:
	var p := get_product(pid)
	for o in p.get("options", []):
		if o.name == option:
			o["stock"] = maxi(0, qty)
	save()
	if notify:
		data_changed.emit()


func _adjust_stock(p: Dictionary, option: String, delta: int) -> void:
	for o in p.options:
		if o.name == option:
			o["stock"] = maxi(0, int(o.stock) + delta)


# ---------------------------------------------------------------- pedidos y ventas

func now_local() -> int:
	var tz: Dictionary = Time.get_time_zone_from_system()
	return int(Time.get_unix_time_from_system()) + int(tz.get("bias", 0)) * 60


func next_order_id() -> int:
	var m := 1000
	for o in orders:
		m = maxi(m, int(o.id))
	return m + 1


func get_order(id: int) -> Dictionary:
	for o in orders:
		if int(o.id) == id:
			return o
	return {}


## lines: [{pid, option, qty}]. Descuenta inventario y registra el pedido/venta.
func create_order(customer: Dictionary, lines: Array, payment: String, channel: String = "Tienda online", status: String = "Pendiente", shipping: int = -1) -> Dictionary:
	if lines.is_empty():
		return {"ok": false, "error": "No hay productos en el pedido"}
	for l in lines:
		var p := get_product(int(l.pid))
		if p.is_empty() or not p.active:
			return {"ok": false, "error": "Un producto ya no está disponible"}
		if stock_of(p, str(l.option)) < int(l.qty):
			return {"ok": false, "error": "No hay existencias suficientes de %s (%s)" % [p.name, l.option]}
	var items: Array = []
	var subtotal := 0
	for l in lines:
		var p := get_product(int(l.pid))
		_adjust_stock(p, str(l.option), -int(l.qty))
		items.append({
			"pid": int(p.id),
			"name": p.name,
			"option": str(l.option),
			"category": p.category,
			"qty": int(l.qty),
			"price": int(p.price),
		})
		subtotal += int(p.price) * int(l.qty)
	if shipping < 0:
		shipping = Cart.shipping_for(subtotal)
	var now := now_local()
	var order := {
		"id": next_order_id(),
		"ts": now,
		"date": Time.get_datetime_string_from_unix_time(now, true),
		"customer": customer,
		"items": items,
		"subtotal": subtotal,
		"shipping": shipping,
		"total": subtotal + shipping,
		"payment": payment,
		"channel": channel,
		"status": status,
	}
	orders.append(order)
	save()
	data_changed.emit()
	return {"ok": true, "order": order}


## Devuelve "" si salió bien o un mensaje de error.
func set_order_status(id: int, status: String) -> String:
	var o := get_order(id)
	if o.is_empty():
		return "Pedido no encontrado"
	var old: String = o.status
	if old == status:
		return ""
	if status == "Cancelado":
		for it in o["items"]:
			var p := get_product(int(it.pid))
			if not p.is_empty():
				_adjust_stock(p, str(it.option), int(it.qty))
	elif old == "Cancelado":
		for it in o["items"]:
			var p := get_product(int(it.pid))
			if p.is_empty() or stock_of(p, str(it.option)) < int(it.qty):
				return "No hay inventario suficiente para reactivar este pedido"
		for it in o["items"]:
			_adjust_stock(get_product(int(it.pid)), str(it.option), -int(it.qty))
	o["status"] = status
	save()
	data_changed.emit()
	return ""


func delete_order(id: int) -> String:
	var o := get_order(id)
	if o.is_empty():
		return ""
	if o.status != "Cancelado":
		return "Solo se pueden eliminar pedidos cancelados"
	orders.erase(o)
	save()
	data_changed.emit()
	return ""


# ---------------------------------------------------------------- administración

func verify_admin(pw: String) -> bool:
	return hash_password(pw) == str(settings.get("admin_hash", ""))


func set_admin_password(pw: String) -> void:
	settings["admin_hash"] = hash_password(pw)
	_write_local()


func set_remote(url: String, header: String) -> void:
	settings["remote_url"] = url.strip_edges()
	settings["remote_header"] = header.strip_edges()
	_write_local()
	if has_remote():
		_set_sync("Conectando…")
		pull()
	else:
		_set_sync("Base de datos local")


func reset_demo() -> void:
	products.clear()
	orders.clear()
	_seed()
	save()
	data_changed.emit()


# ---------------------------------------------------------------- estadísticas

func stats() -> Dictionary:
	var revenue := 0
	var count := 0
	var units := 0
	var pending := 0
	var by_cat: Dictionary = {}
	var by_prod: Dictionary = {}
	var days: Dictionary = {}
	var now := now_local()
	var order_days: Array = []
	for i in range(6, -1, -1):
		var ds: String = Time.get_date_string_from_unix_time(now - i * 86400)
		days[ds] = 0
		order_days.append(ds)
	for o in orders:
		if o.status == "Pendiente":
			pending += 1
		if o.status == "Cancelado":
			continue
		revenue += int(o.total)
		count += 1
		var day: String = str(o.date).substr(0, 10)
		if days.has(day):
			days[day] = int(days[day]) + int(o.total)
		for it in o["items"]:
			units += int(it.qty)
			var line: int = int(it.price) * int(it.qty)
			by_cat[it.category] = int(by_cat.get(it.category, 0)) + line
			var key: String = str(it.name)
			if not by_prod.has(key):
				by_prod[key] = {"name": key, "units": 0, "revenue": 0}
			by_prod[key]["units"] = int(by_prod[key]["units"]) + int(it.qty)
			by_prod[key]["revenue"] = int(by_prod[key]["revenue"]) + line
	var top: Array = by_prod.values()
	top.sort_custom(func(a, b): return a.units > b.units)
	var last7: Array = []
	for ds in order_days:
		last7.append({"date": ds, "total": days[ds]})
	var low: Array = []
	for p in products:
		for o in p.options:
			if int(o.stock) <= LOW_STOCK:
				low.append({"name": p.name, "option": o.name, "stock": int(o.stock)})
	low.sort_custom(func(a, b): return a.stock < b.stock)
	return {
		"revenue": revenue,
		"orders": count,
		"units": units,
		"avg": (revenue / count) if count > 0 else 0,
		"pending": pending,
		"by_cat": by_cat,
		"top": top.slice(0, 8),
		"last7": last7,
		"low": low,
	}


# ---------------------------------------------------------------- datos de ejemplo

func _sizes(list: Array, base: int) -> Array:
	var out: Array = []
	for i in range(list.size()):
		out.append({"name": list[i], "stock": base + (i * 3) % 7, "color": ""})
	return out


func _tones(list: Array) -> Array:
	var out: Array = []
	for i in range(list.size()):
		out.append({"name": list[i][0], "color": list[i][1], "stock": 6 + (i * 5) % 11})
	return out


func _mk(pname: String, cat: String, brand: String, price: int, desc: String, details: Array, label: String, options: Array, sku: String, featured: bool = false) -> void:
	products.append({
		"id": next_product_id(),
		"name": pname,
		"category": cat,
		"brand": brand,
		"price": price,
		"description": desc,
		"details": details,
		"option_label": label,
		"options": options,
		"images": [str(PRODUCT_IMAGES.get(sku, ""))] if PRODUCT_IMAGES.has(sku) else [],
		"active": true,
		"featured": featured,
		"sku": sku,
	})


func _seed() -> void:
	var unica := func(n: int) -> Array: return [{"name": "Única", "stock": n, "color": ""}]
	# Ropa
	_mk("Vestido satín midi Aurora", "Ropa", "Glow Up", 189900,
		"Vestido midi en satín fluido con tirantes ajustables y caída elegante. Ideal para cenas, eventos y celebraciones.",
		["Tela: satín con forro interior", "Cierre invisible lateral", "Largo midi", "Lavado a mano en agua fría"],
		"Talla", _sizes(["XS", "S", "M", "L", "XL"], 3), "GU-RP-001", true)
	_mk("Blazer oversize crema", "Ropa", "Glow Up", 259900,
		"Blazer de corte oversize con hombros estructurados y bolsillos laterales. Se combina con jean o con vestido.",
		["Tela: mezcla de poliéster y viscosa", "Forro completo", "Dos bolsillos con solapa", "Botón único frontal"],
		"Talla", _sizes(["S", "M", "L"], 4), "GU-RP-002", true)
	_mk("Jean mom fit tiro alto", "Ropa", "Denim Co.", 149900,
		"Jean de tiro alto y pierna recta con lavado medio. Comodidad todo el día.",
		["Algodón con elastano", "Tiro alto", "Cinco bolsillos", "Lavado medio"],
		"Talla", _sizes(["6", "8", "10", "12", "14"], 4), "GU-RP-003")
	_mk("Top corset rosé", "Ropa", "Glow Up", 89900,
		"Top tipo corset con varillas suaves y espalda con cordón ajustable.",
		["Tela elástica suave", "Varillas flexibles", "Espalda con cordón"],
		"Talla", _sizes(["XS", "S", "M", "L"], 3), "GU-RP-004")
	# Zapatos
	_mk("Tenis plataforma Cloud", "Zapatos", "Stride", 229900,
		"Tenis blancos con plataforma ligera y suela antideslizante. Se ven bien con todo.",
		["Capellada sintética premium", "Plataforma de 4 cm", "Plantilla acolchada", "Suela de goma"],
		"Talla", _sizes(["35", "36", "37", "38", "39", "40"], 2), "GU-ZP-001", true)
	_mk("Sandalia tacón bloque nude", "Zapatos", "Luna Shoes", 169900,
		"Sandalia de tacón bloque de 7 cm con tira al tobillo y hebilla.",
		["Material sintético", "Tacón de 7 cm", "Hebilla ajustable", "Plantilla acolchada"],
		"Talla", _sizes(["35", "36", "37", "38", "39"], 3), "GU-ZP-002")
	_mk("Botines cuero moka", "Zapatos", "Luna Shoes", 319900,
		"Botines en cuero color moka con tacón bajo y cierre lateral.",
		["Cuero genuino", "Tacón de 5 cm", "Cierre lateral", "Forro textil"],
		"Talla", _sizes(["36", "37", "38", "39", "40"], 2), "GU-ZP-003")
	# Accesorios
	_mk("Bolso mini crossbody perla", "Accesorios", "Glow Up", 139900,
		"Bolso pequeño con correa ajustable y herraje dorado. Cabe celular, llaves y labial.",
		["Material sintético texturizado", "Correa ajustable", "Medidas: 20 x 14 x 7 cm"],
		"", unica.call(14), "GU-AC-001", true)
	_mk("Gafas cat-eye dorado", "Accesorios", "Sol y Mar", 79900,
		"Gafas de sol estilo cat-eye con montura dorada y lentes con protección UV400.",
		["Protección UV400", "Montura metálica", "Incluye estuche"],
		"", unica.call(20), "GU-AC-002")
	_mk("Set de aretes Luna", "Accesorios", "Glow Up", 49900,
		"Set de tres pares de aretes en baño dorado: argolla, perla y media luna.",
		["Baño de oro", "Hipoalergénico", "3 pares"],
		"", unica.call(30), "GU-AC-003")
	# Maquillaje
	_mk("Labial mate Velvet", "Maquillaje", "Glow Beauty", 42900,
		"Labial de acabado mate aterciopelado, alta pigmentación y hasta 8 horas de duración.",
		["Acabado mate", "Fórmula cómoda sin resecar", "Peso: 3,5 g"],
		"Tono", _tones([["Rosa nude", "#D9948A"], ["Rojo cereza", "#B3263B"], ["Coral", "#E5705A"], ["Mauve", "#A8657A"], ["Vino", "#6E1F34"]]), "GU-MQ-001", true)
	_mk("Base Skin Glow", "Maquillaje", "Glow Beauty", 79900,
		"Base líquida de cobertura media con acabado luminoso natural. Controla el brillo y deja la piel uniforme.",
		["Cobertura media modulable", "Acabado luminoso", "30 ml", "Libre de aceites"],
		"Tono", _tones([["Porcelana", "#F3D9C7"], ["Beige claro", "#E8C3A0"], ["Beige medio", "#D2A27C"], ["Canela", "#B57C58"], ["Caramelo", "#9A6240"]]), "GU-MQ-002")
	_mk("Rubor cremoso Peach", "Maquillaje", "Glow Beauty", 54900,
		"Rubor en crema de fácil difuminado que da un efecto de mejillas naturalmente sonrojadas.",
		["Textura cremosa", "Se aplica con dedos o brocha", "Peso: 6 g"],
		"Tono", _tones([["Peach", "#F2A38C"], ["Rosa", "#E68AA0"], ["Terracota", "#C2694F"]]), "GU-MQ-003")
	_mk("Paleta de sombras Sunset", "Maquillaje", "Glow Beauty", 99900,
		"Paleta de 12 sombras en tonos cálidos mates y satinados, de uso diario a noche.",
		["12 tonos", "Mates y satinados", "Espejo incluido"],
		"", unica.call(12), "GU-MQ-004")
