extends Node
## Paleta, tema y utilidades para construir la interfaz por código.

const INK := Color("#1F1A1C")
const CREAM := Color("#FBF7F3")
const ROSE := Color("#C9506B")
const ROSE_DARK := Color("#A83A55")
const GOLD := Color("#B8895B")
const MUTED := Color("#7A6F72")
const LINE := Color("#E9DFD8")
const WHITE := Color.WHITE
const OK := Color("#2E8B57")
const WARN := Color("#D98E04")
const DANGER := Color("#C0392B")
const CLEAR := Color(0, 0, 0, 0)

var _bold: FontVariation


func _ready() -> void:
	_bold = FontVariation.new()
	_bold.base_font = ThemeDB.fallback_font
	_bold.variation_embolden = 0.5


func style(bg: Color, radius: int = 12, border: Color = CLEAR, bw: int = 0, ph: int = 12, pv: int = 8) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.set_corner_radius_all(radius)
	s.border_color = border
	s.set_border_width_all(bw)
	s.content_margin_left = ph
	s.content_margin_right = ph
	s.content_margin_top = pv
	s.content_margin_bottom = pv
	return s


func make_theme() -> Theme:
	var t := Theme.new()
	t.default_font_size = 16
	for c in ["Button", "OptionButton", "MenuButton"]:
		t.set_stylebox("normal", c, style(WHITE, 10, LINE, 1, 16, 10))
		t.set_stylebox("hover", c, style(Color("#F8EEEA"), 10, ROSE, 1, 16, 10))
		t.set_stylebox("pressed", c, style(Color("#F4DEE3"), 10, ROSE, 1, 16, 10))
		t.set_stylebox("disabled", c, style(Color("#F1ECE9"), 10, LINE, 1, 16, 10))
		t.set_stylebox("focus", c, StyleBoxEmpty.new())
		t.set_color("font_color", c, INK)
		t.set_color("font_hover_color", c, INK)
		t.set_color("font_pressed_color", c, ROSE_DARK)
		t.set_color("font_focus_color", c, INK)
		t.set_color("font_disabled_color", c, Color("#B4AAAD"))
	for c in ["Label", "CheckBox", "CheckButton"]:
		t.set_color("font_color", c, INK)
	for c in ["CheckBox", "CheckButton"]:
		t.set_color("font_hover_color", c, INK)
		t.set_color("font_pressed_color", c, INK)
		t.set_color("font_focus_color", c, INK)
		t.set_stylebox("focus", c, StyleBoxEmpty.new())
	for c in ["LineEdit", "TextEdit"]:
		t.set_stylebox("normal", c, style(WHITE, 10, LINE, 1, 12, 10))
		t.set_stylebox("focus", c, style(WHITE, 10, ROSE, 2, 12, 10))
		t.set_stylebox("read_only", c, style(Color("#F4EFEC"), 10, LINE, 1, 12, 10))
		t.set_color("font_color", c, INK)
		t.set_color("font_placeholder_color", c, Color("#A89DA0"))
		t.set_color("caret_color", c, ROSE)
		t.set_color("selection_color", c, Color(0.79, 0.31, 0.42, 0.3))
	t.set_stylebox("panel", "PanelContainer", style(WHITE, 14, LINE, 1, 16, 16))
	t.set_stylebox("panel", "TabContainer", style(WHITE, 14, LINE, 1, 16, 16))
	t.set_stylebox("tab_selected", "TabContainer", style(WHITE, 10, LINE, 1, 16, 10))
	t.set_stylebox("tab_unselected", "TabContainer", style(Color("#F4EDE8"), 10, CLEAR, 0, 16, 10))
	t.set_stylebox("tab_hovered", "TabContainer", style(Color("#F8EEEA"), 10, CLEAR, 0, 16, 10))
	t.set_stylebox("tab_focus", "TabContainer", StyleBoxEmpty.new())
	t.set_color("font_selected_color", "TabContainer", ROSE_DARK)
	t.set_color("font_unselected_color", "TabContainer", MUTED)
	t.set_color("font_hovered_color", "TabContainer", INK)
	t.set_stylebox("background", "ProgressBar", style(Color("#F1E9E4"), 8, CLEAR, 0, 0, 0))
	t.set_stylebox("fill", "ProgressBar", style(ROSE, 8, CLEAR, 0, 0, 0))
	return t


func label(text: String, size: int = 16, color: Color = INK, bold: bool = false, wrap: bool = false) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	if bold:
		l.add_theme_font_override("font", _bold)
	if wrap:
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l


func button(text: String, primary: bool = false, danger: bool = false) -> Button:
	var b := Button.new()
	b.text = text
	b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	if primary:
		b.add_theme_stylebox_override("normal", style(ROSE, 10, CLEAR, 0, 20, 12))
		b.add_theme_stylebox_override("hover", style(ROSE_DARK, 10, CLEAR, 0, 20, 12))
		b.add_theme_stylebox_override("pressed", style(ROSE_DARK, 10, CLEAR, 0, 20, 12))
		b.add_theme_stylebox_override("disabled", style(Color("#E5C9D0"), 10, CLEAR, 0, 20, 12))
		for k in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_disabled_color"]:
			b.add_theme_color_override(k, WHITE)
	elif danger:
		for k in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
			b.add_theme_color_override(k, DANGER)
	return b


func chip(text: String, active: bool) -> Button:
	var b := Button.new()
	b.text = text
	b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	if active:
		b.add_theme_stylebox_override("normal", style(INK, 22, INK, 1, 18, 8))
		b.add_theme_stylebox_override("hover", style(INK, 22, INK, 1, 18, 8))
		b.add_theme_stylebox_override("pressed", style(INK, 22, INK, 1, 18, 8))
		for k in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
			b.add_theme_color_override(k, WHITE)
	else:
		b.add_theme_stylebox_override("normal", style(WHITE, 22, LINE, 1, 18, 8))
		b.add_theme_stylebox_override("hover", style(Color("#F8EEEA"), 22, ROSE, 1, 18, 8))
		b.add_theme_stylebox_override("pressed", style(Color("#F8EEEA"), 22, ROSE, 1, 18, 8))
	return b


func card(pad: int = 16) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", style(WHITE, 14, LINE, 1, pad, pad))
	return p


func vbox(sep: int = 8) -> VBoxContainer:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", sep)
	return v


func hbox(sep: int = 8) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", sep)
	return h


func spacer(h: int = 8) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(0, h)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return c


func hr() -> HSeparator:
	var s := HSeparator.new()
	s.add_theme_stylebox_override("separator", style(LINE, 0, CLEAR, 0, 0, 0))
	s.add_theme_constant_override("separation", 1)
	return s


func ignore_mouse(node: Node) -> void:
	if node is Control:
		(node as Control).mouse_filter = Control.MOUSE_FILTER_IGNORE
	for c in node.get_children():
		ignore_mouse(c)


func toast(text: String) -> void:
	var scene: Node = get_tree().current_scene
	if scene == null:
		return
	var holder := VBoxContainer.new()
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	holder.alignment = BoxContainer.ALIGNMENT_END
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", style(INK, 24, CLEAR, 0, 22, 12))
	p.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_child(label(text, 15, WHITE))
	holder.add_child(p)
	holder.add_child(spacer(36))
	scene.add_child(holder)
	holder.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var tw := create_tween()
	tw.tween_interval(1.8)
	tw.tween_property(holder, "modulate:a", 0.0, 0.4)
	tw.tween_callback(holder.queue_free)
