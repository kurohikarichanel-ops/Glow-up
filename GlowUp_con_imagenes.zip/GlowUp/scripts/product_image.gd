class_name ProductImage
extends TextureRect
## Muestra la primera foto disponible de una lista (archivo local o URL).
## Si ninguna carga, deja una imagen de respaldo generada.

var sources: Array = []
var category := ""
var key := ""
var _idx := 0
var _http: HTTPRequest = null


func setup(srcs: Array, cat: String, k: String) -> void:
	sources = srcs.duplicate()
	category = cat
	key = k
	_idx = 0
	if _http != null:
		_http.cancel_request()
		_http.queue_free()
		_http = null
	expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	texture = Util.placeholder(cat, k)
	# Se difiere para que el nodo ya esté en el árbol (HTTPRequest lo necesita).
	call_deferred("_try_next")


func _try_next() -> void:
	if _http != null or not is_inside_tree():
		return
	while _idx < sources.size():
		var src: String = str(sources[_idx]).strip_edges()
		_idx += 1
		if src == "":
			continue
		if src.begins_with("http"):
			if Util.url_cache.has(src):
				texture = Util.url_cache[src]
				return
			_http = HTTPRequest.new()
			_http.timeout = 12.0
			add_child(_http)
			_http.request_completed.connect(_on_done.bind(src))
			if _http.request(src) == OK:
				return
			_http.queue_free()
			_http = null
		else:
			if not FileAccess.file_exists(src):
				continue
			var img := Image.load_from_file(src)
			if img != null and not img.is_empty():
				texture = ImageTexture.create_from_image(img)
				return


func _on_done(result: int, code: int, _headers: PackedStringArray, body: PackedByteArray, src: String) -> void:
	if _http != null:
		_http.queue_free()
		_http = null
	if result == HTTPRequest.RESULT_SUCCESS and code >= 200 and code < 300 and body.size() > 8:
		var img := Image.new()
		var err: int = ERR_FILE_UNRECOGNIZED
		if body[0] == 0x89 and body[1] == 0x50:
			err = img.load_png_from_buffer(body)
		elif body[0] == 0xFF and body[1] == 0xD8:
			err = img.load_jpg_from_buffer(body)
		elif body[0] == 0x52 and body[1] == 0x49:
			err = img.load_webp_from_buffer(body)
		if err == OK and not img.is_empty():
			var tex := ImageTexture.create_from_image(img)
			Util.url_cache[src] = tex
			texture = tex
			return
	_try_next()
