extends Node
## Utilidades: formato de pesos colombianos e imágenes de respaldo generadas.

const CAT_COLORS := {
	"Ropa": [Color("#F0C2CA"), Color("#B5495B")],
	"Zapatos": [Color("#E3D0B4"), Color("#8A6A45")],
	"Accesorios": [Color("#D3C4EA"), Color("#6B4E9B")],
	"Maquillaje": [Color("#F9CFC2"), Color("#C4455E")],
}

var _placeholder_cache: Dictionary = {}
var url_cache: Dictionary = {}


func cop(value: float) -> String:
	var n: int = int(round(value))
	var s: String = str(absi(n))
	var out := ""
	var count := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		count += 1
		if count % 3 == 0 and i > 0:
			out = "." + out
	var sign_txt := "-" if n < 0 else ""
	return sign_txt + "$" + out + " COP"


## Imagen de respaldo (degradado + formas suaves) cuando una foto no está disponible.
func placeholder(category: String, key: String) -> ImageTexture:
	var ck: String = category + "|" + key
	if _placeholder_cache.has(ck):
		return _placeholder_cache[ck]
	var cols: Array = CAT_COLORS.get(category, [Color("#EEE4E0"), Color("#9A8A8E")])
	var c0: Color = cols[0]
	var c1: Color = cols[1]
	var w := 400
	var h := 500
	var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
	for y in range(h):
		img.fill_rect(Rect2i(0, y, w, 1), c0.lerp(c1, float(y) / float(h)))
	var hv: int = absi(key.hash())
	var cx: int = 130 + (hv % 140)
	var cy: int = 150 + ((hv / 7) % 100)
	var r := 110
	for y in range(maxi(cy - r, 0), mini(cy + r, h)):
		for x in range(maxi(cx - r, 0), mini(cx + r, w)):
			var dx: int = x - cx
			var dy: int = y - cy
			if dx * dx + dy * dy <= r * r:
				var base: Color = img.get_pixel(x, y)
				img.set_pixel(x, y, base.lerp(Color.WHITE, 0.22))
	var tex := ImageTexture.create_from_image(img)
	_placeholder_cache[ck] = tex
	return tex
