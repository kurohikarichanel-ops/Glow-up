class_name AdminPanel
extends VBoxContainer
## Panel de administración: productos, inventario, pedidos, ventas, estadísticas y ajustes.
## Todos los cambios pasan por Database, así que la tienda pública se actualiza al instante.

signal exit_admin
signal logout
signal tab_changed_index(i: int)

const SALE_PAYMENTS := ["Efectivo", "Tarjeta (datáfono)", "Transferencia", "Nequi / Daviplata"]

var tab_index := 0
var compact := false
var order_filter := "Todos"
var _prod_search := ""
var _tabs: TabContainer
var _edit_dialog: ConfirmationDialog
var _edit_err: Label
var _f: Dictionary = {}
var _editing_id := 0


func build(is_compact: bool) -> void:
	compact = is_compact
	add_theme_constant_override("separation", 14)
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var top := HFlowContainer.new()
	top.add_theme_constant_override("h_separation", 10)
	top.add_theme_constant_override("v_separation", 8)
	var title := UI.label("Panel de administración", 26, UI.INK, true)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(title)
	var shop := UI.button("Ver tienda")
	shop.pressed.connect(func(): exit_admin.emit())
	top.add_child(shop)
	var out := UI.button("Cerrar sesión", false, true)
	out.pressed.connect(func(): logout.emit())
	top.add_child(out)
	add_child(top)

	_tabs = TabContainer.new()
	_tabs.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	add_child(_tabs)
	_tabs.add_child(_tab_products())
	_tabs.add_child(_tab_inventory())
	_tabs.add_child(_tab_orders())
	_tabs.add_child(_tab_sales())
	_tabs.add_child(_tab_stats())
	_tabs.add_child(_tab_settings())
	_tabs.current_tab = clampi(tab_index, 0, _tabs.get_tab_count() - 1)
	_tabs.tab_changed.connect(func(i: int):
		tab_index = i
		tab_changed_index.emit(i))


# ---------------------------------------------------------------- utilidades

func _clear(n: Node) -> void:
	for c in n.get_children():
		n.remove_child(c)
		c.queue_free()


func _confirm(text: String, on_ok: Callable) -> void:
	var d := ConfirmationDialog.new()
	d.dialog_text = text
	d.ok_button_text = "Sí, continuar"
	d.cancel_button_text = "Cancelar"
	d.confirmed.connect(on_ok)
	d.confirmed.connect(d.queue_free)
	d.canceled.connect(d.queue_free)
	add_child(d)
	d.popup_centered(Vector2i(380, 140))


func _flow(sep: int = 8) -> HFlowContainer:
	var f := HFlowContainer.new()
	f.add_theme_constant_override("h_separation", sep)
	f.add_theme_constant_override("v_separation", sep)
	return f


func _field(parent: Control, caption: String, ctl: Control) -> void:
	parent.add_child(UI.label(caption, 14, UI.MUTED))
	parent.add_child(ctl)


func _kpi(caption: String, value: String) -> Control:
	var c := UI.card(14)
	c.custom_minimum_size.x = 150 if compact else 200
	var v := UI.vbox(2)
	v.add_child(UI.label(caption, 13, UI.MUTED))
	v.add_child(UI.label(value, 20 if compact else 24, UI.INK, true))
	c.add_child(v)
	return c


func _bar_row(caption: String, value: float, max_v: float, text: String) -> Control:
	var h := UI.hbox(10)
	var l := UI.label(caption, 14)
	l.custom_minimum_size.x = 90 if compact else 120
	h.add_child(l)
	var b := ProgressBar.new()
	b.max_value = maxf(max_v, 1.0)
	b.value = value
	b.show_percentage = false
	b.custom_minimum_size = Vector2(0, 16)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(b)
	var t := UI.label(text, 14, UI.MUTED)
	t.custom_minimum_size.x = 110 if compact else 140
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	h.add_child(t)
	return h


# ---------------------------------------------------------------- pestaña: productos

func _tab_products() -> Control:
	var v := UI.vbox(10)
	v.name = "Productos"
	var bar := _flow(10)
	var add := UI.button("+ Nuevo producto", true)
	add.pressed.connect(_open_editor.bind(0))
	bar.add_child(add)
	var search := LineEdit.new()
	search.placeholder_text = "Buscar producto..."
	search.text = _prod_search
	search.custom_minimum_size.x = 240
	bar.add_child(search)
	v.add_child(bar)
	var list := UI.vbox(8)
	v.add_child(list)
	_fill_products(list)
	search.text_changed.connect(func(t: String):
		_prod_search = t
		_fill_products(list))
	return v


func _fill_products(list: VBoxContainer) -> void:
	_clear(list)
	var q: String = _prod_search.strip_edges().to_lower()
	var shown := 0
	for p in Database.products:
		if q != "" and not (str(p.name) + " " + str(p.sku) + " " + str(p.category)).to_lower().contains(q):
			continue
		shown += 1
		list.add_child(_product_row(p))
	if shown == 0:
		list.add_child(UI.label("No hay productos para mostrar.", 15, UI.MUTED))


func _product_row(p: Dictionary) -> Control:
	var card := UI.card(10)
	var h := UI.hbox(10)
	var img := ProductImage.new()
	img.custom_minimum_size = Vector2(56, 70)
	h.add_child(img)
	img.setup(p.images, p.category, str(p.id))
	var info := UI.vbox(2)
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info.add_child(UI.label(p.name, 15, UI.INK, true, true))
	var stock: int = Database.total_stock(p)
	var meta := "%s  -  %s  -  Stock: %d" % [p.category, Util.cop(p.price), stock]
	info.add_child(UI.label(meta, 13, UI.DANGER if stock <= 0 else UI.MUTED, false, true))
	h.add_child(info)
	var side := _flow(6)
	side.size_flags_horizontal = Control.SIZE_SHRINK_END
	var vis := CheckBox.new()
	vis.text = "" if compact else "Visible"
	vis.button_pressed = p.active
	var pid: int = int(p.id)
	vis.toggled.connect(func(on: bool):
		var pp: Dictionary = Database.get_product(pid)
		pp["active"] = on
		Database.upsert_product(pp))
	side.add_child(vis)
	var ed := UI.button("Editar")
	ed.pressed.connect(_open_editor.bind(pid))
	side.add_child(ed)
	var del := UI.button("Eliminar", false, true)
	var pname: String = str(p.name)
	del.pressed.connect(func(): _confirm("¿Eliminar \"%s\"? Esta acción no se puede deshacer." % pname, func(): Database.delete_product(pid)))
	side.add_child(del)
	h.add_child(side)
	card.add_child(h)
	return card


# ---------------------------------------------------------------- editor de producto

func _options_to_text(p: Dictionary) -> String:
	var lines: PackedStringArray = []
	for o in p.get("options", []):
		var l: String = "%s;%d" % [o.name, int(o.stock)]
		if str(o.color) != "":
			l += ";" + str(o.color)
		lines.append(l)
	return "\n".join(lines)


func _parse_options(text: String, label: String) -> Array:
	var out: Array = []
	for line in text.split("\n", false):
		var parts: PackedStringArray = line.strip_edges().split(";")
		var nm: String = parts[0].strip_edges()
		if nm == "":
			continue
		var o := {"name": nm, "stock": 0, "color": ""}
		if parts.size() > 1:
			o["stock"] = maxi(0, int(parts[1].strip_edges()))
		if parts.size() > 2:
			o["color"] = parts[2].strip_edges()
		out.append(o)
	if label == "" and out.size() > 0:
		out = [{"name": "Única", "stock": out[0].stock, "color": ""}]
	return out


func _open_editor(pid: int) -> void:
	_editing_id = pid
	var p: Dictionary = Database.get_product(pid) if pid > 0 else {}
	if _edit_dialog != null and is_instance_valid(_edit_dialog):
		_edit_dialog.queue_free()
	_edit_dialog = ConfirmationDialog.new()
	_edit_dialog.title = "Editar producto" if pid > 0 else "Nuevo producto"
	_edit_dialog.ok_button_text = "Guardar"
	_edit_dialog.cancel_button_text = "Cancelar"
	_edit_dialog.confirmed.connect(_save_editor)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var v := UI.vbox(8)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(v)
	_edit_dialog.add_child(scroll)

	_f = {}
	_edit_err = UI.label("", 14, UI.DANGER, false, true)
	v.add_child(_edit_err)
	_f["name"] = LineEdit.new()
	_f.name.text = str(p.get("name", ""))
	_field(v, "Nombre del producto", _f.name)
	_f["category"] = OptionButton.new()
	for c in Database.CATEGORIES:
		_f.category.add_item(c)
	var ci: int = Database.CATEGORIES.find(str(p.get("category", "Ropa")))
	_f.category.selected = maxi(ci, 0)
	_field(v, "Categoría", _f.category)
	_f["brand"] = LineEdit.new()
	_f.brand.text = str(p.get("brand", ""))
	_field(v, "Marca", _f.brand)
	_f["price"] = SpinBox.new()
	_f.price.min_value = 0
	_f.price.max_value = 99999999
	_f.price.step = 100
	_f.price.suffix = "COP"
	_f.price.value = float(p.get("price", 0))
	_f.price.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_field(v, "Precio (pesos colombianos)", _f.price)
	_f["sku"] = LineEdit.new()
	_f.sku.text = str(p.get("sku", ""))
	_field(v, "Referencia / SKU", _f.sku)
	_f["description"] = TextEdit.new()
	_f.description.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	_f.description.custom_minimum_size.y = 90
	_f.description.text = str(p.get("description", ""))
	_field(v, "Descripción", _f.description)
	_f["details"] = TextEdit.new()
	_f.details.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	_f.details.custom_minimum_size.y = 90
	_f.details.text = "\n".join(PackedStringArray(p.get("details", [])))
	_field(v, "Detalles de la ficha (uno por línea)", _f.details)
	_f["label"] = OptionButton.new()
	for s in ["Sin variantes (única)", "Talla", "Tono"]:
		_f.label.add_item(s)
	var lbl: String = str(p.get("option_label", ""))
	_f.label.selected = 0 if lbl == "" else (1 if lbl == "Talla" else 2)
	_field(v, "Tipo de variante", _f.label)
	_f["options"] = TextEdit.new()
	_f.options.custom_minimum_size.y = 110
	_f.options.text = _options_to_text(p) if pid > 0 else "Única;10"
	_field(v, "Variantes e inventario - una por línea: nombre;stock;#color (el color solo para tonos). Sin variantes: Única;stock", _f.options)
	_f["images"] = TextEdit.new()
	_f.images.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	_f.images.custom_minimum_size.y = 90
	_f.images.text = "\n".join(PackedStringArray(p.get("images", [])))
	_field(v, "Fotografías - una por línea (archivo o URL https). Si una falla, se usa la siguiente y al final una imagen de respaldo", _f.images)
	var up := UI.button("Subir fotografías desde mi equipo")
	up.pressed.connect(_pick_images.bind(_f.images))
	v.add_child(up)
	_f["active"] = CheckBox.new()
	_f.active.text = "Visible en la tienda"
	_f.active.button_pressed = bool(p.get("active", true))
	v.add_child(_f.active)
	_f["featured"] = CheckBox.new()
	_f.featured.text = "Producto destacado"
	_f.featured.button_pressed = bool(p.get("featured", false))
	v.add_child(_f.featured)

	add_child(_edit_dialog)
	var vp: Vector2 = get_viewport_rect().size
	_edit_dialog.popup_centered(Vector2i(int(minf(760.0, vp.x - 24.0)), int(minf(780.0, vp.y - 40.0))))


func _pick_images(target: TextEdit) -> void:
	var fd := FileDialog.new()
	fd.file_mode = FileDialog.FILE_MODE_OPEN_FILES
	fd.access = FileDialog.ACCESS_FILESYSTEM
	fd.use_native_dialog = true
	fd.filters = PackedStringArray(["*.png, *.jpg, *.jpeg, *.webp ; Imágenes"])
	fd.files_selected.connect(func(paths: PackedStringArray):
		for p in paths:
			var dst: String = "%s/%d_%s" % [Database.IMG_DIR, Time.get_ticks_msec(), p.get_file()]
			if DirAccess.copy_absolute(p, dst) == OK:
				if target.text.strip_edges() != "":
					target.text += "\n"
				target.text += dst
		fd.queue_free())
	fd.canceled.connect(fd.queue_free)
	add_child(fd)
	fd.popup_centered_ratio(0.7)


func _reopen_editor() -> void:
	if _edit_dialog != null and is_instance_valid(_edit_dialog):
		var vp: Vector2 = get_viewport_rect().size
		_edit_dialog.popup_centered(Vector2i(int(minf(760.0, vp.x - 24.0)), int(minf(780.0, vp.y - 40.0))))


func _save_editor() -> void:
	var nm: String = _f.name.text.strip_edges()
	var label: String = ["", "Talla", "Tono"][_f.label.selected]
	var opts: Array = _parse_options(_f.options.text, label)
	var err := ""
	if nm.length() < 2:
		err = "Escribe el nombre del producto."
	elif int(_f.price.value) <= 0:
		err = "El precio debe ser mayor a cero."
	elif opts.is_empty():
		err = "Agrega al menos una variante con su inventario."
	if err != "":
		_edit_err.text = err
		call_deferred("_reopen_editor")
		return
	var details: Array = []
	for l in _f.details.text.split("\n", false):
		if l.strip_edges() != "":
			details.append(l.strip_edges())
	var images: Array = []
	for l in _f.images.text.split("\n", false):
		if l.strip_edges() != "":
			images.append(l.strip_edges())
	var p := {
		"id": _editing_id,
		"name": nm,
		"category": Database.CATEGORIES[_f.category.selected],
		"brand": _f.brand.text.strip_edges(),
		"price": int(_f.price.value),
		"description": _f.description.text.strip_edges(),
		"details": details,
		"option_label": label,
		"options": opts,
		"images": images,
		"active": _f.active.button_pressed,
		"featured": _f.featured.button_pressed,
		"sku": _f.sku.text.strip_edges(),
	}
	Database.upsert_product(p)
	UI.toast("Producto guardado")


# ---------------------------------------------------------------- pestaña: inventario

func _tab_inventory() -> Control:
	var v := UI.vbox(10)
	v.name = "Inventario"
	v.add_child(UI.label("Ajusta las existencias de cada variante. Los cambios se guardan al instante.", 14, UI.MUTED, false, true))
	for p in Database.products:
		var card := UI.card(12)
		var cv := UI.vbox(8)
		var head := UI.hbox(8)
		var nm := UI.label(p.name, 16, UI.INK, true, true)
		head.add_child(nm)
		var total_lbl := UI.label("Total: %d" % Database.total_stock(p), 14, UI.MUTED)
		head.add_child(total_lbl)
		cv.add_child(head)
		var flow := _flow(12)
		var pid: int = int(p.id)
		for o in p.options:
			var h := UI.hbox(6)
			h.add_child(UI.label(str(o.name), 14, UI.MUTED))
			var sp := SpinBox.new()
			sp.min_value = 0
			sp.max_value = 99999
			sp.step = 1
			sp.value = int(o.stock)
			var oname: String = str(o.name)
			sp.value_changed.connect(func(val: float):
				Database.set_stock(pid, oname, int(val), false)
				total_lbl.text = "Total: %d" % Database.total_stock(Database.get_product(pid)))
			h.add_child(sp)
			flow.add_child(h)
		cv.add_child(flow)
		card.add_child(cv)
		v.add_child(card)
	return v


# ---------------------------------------------------------------- pestaña: pedidos

func _tab_orders() -> Control:
	var v := UI.vbox(10)
	v.name = "Pedidos"
	var bar := _flow(10)
	bar.add_child(UI.label("Estado:", 15, UI.MUTED))
	var filt := OptionButton.new()
	var all: Array = ["Todos"]
	all.append_array(Database.STATUSES)
	for s in all:
		filt.add_item(s)
	filt.selected = maxi(all.find(order_filter), 0)
	bar.add_child(filt)
	v.add_child(bar)
	var list := UI.vbox(10)
	v.add_child(list)
	_fill_orders(list)
	filt.item_selected.connect(func(i: int):
		order_filter = all[i]
		_fill_orders(list))
	return v


func _fill_orders(list: VBoxContainer) -> void:
	_clear(list)
	var sorted: Array = Database.orders.duplicate()
	sorted.sort_custom(func(a, b): return int(a.id) > int(b.id))
	var shown := 0
	for o in sorted:
		if order_filter != "Todos" and o.status != order_filter:
			continue
		shown += 1
		list.add_child(_order_card(o))
	if shown == 0:
		list.add_child(UI.label("No hay pedidos para mostrar.", 15, UI.MUTED))


func _order_card(o: Dictionary) -> Control:
	var card := UI.card(14)
	var v := UI.vbox(6)
	var head := _flow(12)
	head.add_child(UI.label("Pedido #%d" % o.id, 18, UI.INK, true))
	head.add_child(UI.label(str(o.date), 14, UI.MUTED))
	head.add_child(UI.label(str(o.channel), 14, UI.GOLD, true))
	v.add_child(head)
	var c: Dictionary = o.customer
	var who: String = str(c.get("name", ""))
	if str(c.get("phone", "")) != "":
		who += "  -  " + str(c.phone)
	v.add_child(UI.label(who, 15, UI.INK, false, true))
	if str(c.get("address", "")) != "":
		v.add_child(UI.label("%s, %s" % [c.address, c.get("city", "")], 14, UI.MUTED, false, true))
	if str(c.get("email", "")) != "":
		v.add_child(UI.label(str(c.email), 14, UI.MUTED, false, true))
	if str(c.get("notes", "")) != "":
		v.add_child(UI.label("Notas: " + str(c.notes), 14, UI.MUTED, false, true))
	for it in o["items"]:
		var t: String = "%d x %s" % [it.qty, it.name]
		if str(it.option) != "Única":
			t += " (%s)" % it.option
		t += "  -  " + Util.cop(int(it.price) * int(it.qty))
		v.add_child(UI.label(t, 14, UI.INK, false, true))
	v.add_child(UI.label("Envío: %s   Total: %s   Pago: %s" % [("Gratis" if int(o.shipping) == 0 else Util.cop(o.shipping)), Util.cop(o.total), o.payment], 14, UI.ROSE_DARK, true, true))
	var row := _flow(8)
	row.add_child(UI.label("Estado:", 14, UI.MUTED))
	var st := OptionButton.new()
	for s in Database.STATUSES:
		st.add_item(s)
	st.selected = Database.STATUSES.find(str(o.status))
	var oid: int = int(o.id)
	st.item_selected.connect(func(i: int):
		var msg: String = Database.set_order_status(oid, Database.STATUSES[i])
		if msg != "":
			UI.toast(msg))
	row.add_child(st)
	if o.status == "Cancelado":
		var del := UI.button("Eliminar", false, true)
		del.pressed.connect(func(): _confirm("¿Eliminar el pedido #%d?" % oid, func(): Database.delete_order(oid)))
		row.add_child(del)
	v.add_child(row)
	card.add_child(v)
	return card


# ---------------------------------------------------------------- pestaña: ventas

func _tab_sales() -> Control:
	var v := UI.vbox(12)
	v.name = "Ventas"
	var c := UI.card(16)
	var cv := UI.vbox(8)
	cv.add_child(UI.label("Registrar venta en tienda física", 18, UI.INK, true))
	var pids: Array = []
	var prod := OptionButton.new()
	for p in Database.products:
		if p.active:
			pids.append(int(p.id))
			prod.add_item(str(p.name))
	var opt := OptionButton.new()
	var fill_opts := func(idx: int):
		opt.clear()
		if idx < 0 or idx >= pids.size():
			return
		var p: Dictionary = Database.get_product(pids[idx])
		for o in p.options:
			opt.add_item("%s (stock %d)" % [o.name, int(o.stock)])
	if pids.size() > 0:
		fill_opts.call(0)
	prod.item_selected.connect(func(i: int): fill_opts.call(i))
	_field(cv, "Producto", prod)
	_field(cv, "Variante", opt)
	var qty := SpinBox.new()
	qty.min_value = 1
	qty.max_value = 999
	qty.value = 1
	_field(cv, "Cantidad", qty)
	var cust := LineEdit.new()
	cust.placeholder_text = "Cliente de mostrador"
	_field(cv, "Cliente (opcional)", cust)
	var pay := OptionButton.new()
	for s in SALE_PAYMENTS:
		pay.add_item(s)
	_field(cv, "Método de pago", pay)
	var msg := UI.label("", 14, UI.DANGER, false, true)
	cv.add_child(msg)
	var reg := UI.button("Registrar venta", true)
	reg.pressed.connect(func():
		if pids.is_empty() or prod.selected < 0 or opt.selected < 0:
			msg.text = "Selecciona un producto y una variante."
			return
		var p: Dictionary = Database.get_product(pids[prod.selected])
		var oname: String = str(p.options[opt.selected].name)
		var who: String = cust.text.strip_edges()
		if who == "":
			who = "Cliente de mostrador"
		var res: Dictionary = Database.create_order({"name": who}, [{"pid": int(p.id), "option": oname, "qty": int(qty.value)}], SALE_PAYMENTS[pay.selected], "Tienda física", "Entregado", 0)
		if res.ok:
			UI.toast("Venta registrada: " + Util.cop(res.order.total))
		else:
			msg.text = str(res.error))
	cv.add_child(reg)
	c.add_child(cv)
	v.add_child(c)

	v.add_child(UI.label("Últimas ventas y pedidos", 18, UI.INK, true))
	var sorted: Array = Database.orders.duplicate()
	sorted.sort_custom(func(a, b): return int(a.id) > int(b.id))
	for i in range(mini(15, sorted.size())):
		var o: Dictionary = sorted[i]
		var row := UI.card(10)
		var h := _flow(12)
		h.add_child(UI.label("#%d" % o.id, 15, UI.INK, true))
		h.add_child(UI.label(str(o.date), 14, UI.MUTED))
		h.add_child(UI.label(str(o.channel), 14, UI.GOLD))
		h.add_child(UI.label(str(o.status), 14, UI.MUTED))
		h.add_child(UI.label(Util.cop(o.total), 15, UI.ROSE_DARK, true))
		row.add_child(h)
		v.add_child(row)
	return v


# ---------------------------------------------------------------- pestaña: estadísticas

func _tab_stats() -> Control:
	var v := UI.vbox(14)
	v.name = "Estadísticas"
	var s: Dictionary = Database.stats()
	var kp := _flow(10)
	kp.add_child(_kpi("Ingresos", Util.cop(s.revenue)))
	kp.add_child(_kpi("Pedidos", str(s.orders)))
	kp.add_child(_kpi("Unidades vendidas", str(s.units)))
	kp.add_child(_kpi("Ticket promedio", Util.cop(s.avg)))
	kp.add_child(_kpi("Pedidos pendientes", str(s.pending)))
	v.add_child(kp)

	var c1 := UI.card(16)
	var v1 := UI.vbox(8)
	v1.add_child(UI.label("Ventas de los últimos 7 días", 18, UI.INK, true))
	var mx := 1.0
	for d in s.last7:
		mx = maxf(mx, float(d.total))
	for d in s.last7:
		v1.add_child(_bar_row(str(d.date).substr(5), float(d.total), mx, Util.cop(d.total)))
	c1.add_child(v1)
	v.add_child(c1)

	var c2 := UI.card(16)
	var v2 := UI.vbox(8)
	v2.add_child(UI.label("Ingresos por categoría", 18, UI.INK, true))
	var mc := 1.0
	for k in s.by_cat:
		mc = maxf(mc, float(s.by_cat[k]))
	if s.by_cat.is_empty():
		v2.add_child(UI.label("Aún no hay ventas.", 14, UI.MUTED))
	for k in s.by_cat:
		v2.add_child(_bar_row(str(k), float(s.by_cat[k]), mc, Util.cop(s.by_cat[k])))
	c2.add_child(v2)
	v.add_child(c2)

	var c3 := UI.card(16)
	var v3 := UI.vbox(6)
	v3.add_child(UI.label("Productos más vendidos", 18, UI.INK, true))
	if s.top.is_empty():
		v3.add_child(UI.label("Aún no hay ventas.", 14, UI.MUTED))
	for t in s.top:
		v3.add_child(UI.label("%s  -  %d uds  -  %s" % [t.name, t.units, Util.cop(t.revenue)], 14, UI.INK, false, true))
	c3.add_child(v3)
	v.add_child(c3)

	var c4 := UI.card(16)
	var v4 := UI.vbox(6)
	v4.add_child(UI.label("Alertas de inventario bajo (%d o menos)" % Database.LOW_STOCK, 18, UI.INK, true))
	if s.low.is_empty():
		v4.add_child(UI.label("Todo el inventario está en niveles saludables.", 14, UI.OK))
	for l in s.low:
		var col: Color = UI.DANGER if int(l.stock) == 0 else UI.WARN
		v4.add_child(UI.label("%s (%s): %d" % [l.name, l.option, l.stock], 14, col, false, true))
	c4.add_child(v4)
	v.add_child(c4)
	return v


# ---------------------------------------------------------------- pestaña: ajustes

func _tab_settings() -> Control:
	var v := UI.vbox(14)
	v.name = "Ajustes"

	var c1 := UI.card(16)
	var v1 := UI.vbox(8)
	v1.add_child(UI.label("Cambiar contraseña de administración", 18, UI.INK, true))
	var p1 := LineEdit.new()
	p1.secret = true
	p1.placeholder_text = "Nueva contraseña (mínimo 8 caracteres)"
	v1.add_child(p1)
	var p2 := LineEdit.new()
	p2.secret = true
	p2.placeholder_text = "Repite la contraseña"
	v1.add_child(p2)
	var pm := UI.label("", 14, UI.DANGER, false, true)
	v1.add_child(pm)
	var pb := UI.button("Guardar contraseña", true)
	pb.pressed.connect(func():
		if p1.text.length() < 8:
			pm.text = "Usa al menos 8 caracteres."
		elif p1.text != p2.text:
			pm.text = "Las contraseñas no coinciden."
		else:
			Database.set_admin_password(p1.text)
			p1.text = ""
			p2.text = ""
			pm.text = ""
			UI.toast("Contraseña actualizada"))
	v1.add_child(pb)
	c1.add_child(v1)
	v.add_child(c1)

	var c2 := UI.card(16)
	var v2 := UI.vbox(8)
	v2.add_child(UI.label("Base de datos compartida (sincronización)", 18, UI.INK, true))
	v2.add_child(UI.label("Por defecto los datos viven en este dispositivo. Para compartirlos entre varios dispositivos, indica la URL de un servicio REST que acepte GET y PUT de un documento JSON (por ejemplo un bucket JSON, Supabase o Firebase). Usa URLs https para las fotos si quieres que se vean en todos los dispositivos.", 14, UI.MUTED, false, true))
	var url := LineEdit.new()
	url.placeholder_text = "https://..."
	url.text = str(Database.settings.get("remote_url", ""))
	_field(v2, "URL de la base remota", url)
	var hdr := LineEdit.new()
	hdr.placeholder_text = "Ejemplo: X-Master-Key: abc123"
	hdr.text = str(Database.settings.get("remote_header", ""))
	_field(v2, "Encabezado de autenticación (opcional)", hdr)
	var st := UI.label(Database.sync_msg, 14, UI.MUTED, false, true)
	v2.add_child(st)
	Database.sync_status.connect(func(m: String):
		if is_instance_valid(st):
			st.text = m)
	var sb := UI.button("Guardar y sincronizar", true)
	sb.pressed.connect(func(): Database.set_remote(url.text, hdr.text))
	v2.add_child(sb)
	c2.add_child(v2)
	v.add_child(c2)

	var c3 := UI.card(16)
	var v3 := UI.vbox(8)
	v3.add_child(UI.label("Datos", 18, UI.INK, true))
	v3.add_child(UI.label("Archivo de la base de datos local:", 14, UI.MUTED))
	var path := LineEdit.new()
	path.text = Database.export_path()
	path.editable = false
	v3.add_child(path)
	var rb := UI.button("Restaurar datos de demostración", false, true)
	rb.pressed.connect(func(): _confirm("Se borrarán todos los productos y pedidos y se cargarán los datos de ejemplo. ¿Continuar?", func(): Database.reset_demo()))
	v3.add_child(rb)
	c3.add_child(v3)
	v.add_child(c3)
	return v
