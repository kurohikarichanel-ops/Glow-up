# Glow Up - tienda virtual en Godot 4

Tienda de ropa, zapatos, accesorios y maquillaje con carrito, pedidos y panel de administración.
Precios en pesos colombianos (COP). La interfaz se adapta a celular y computador.

## Cómo abrirlo
1. Instala Godot 4.3 o superior (versión estándar, sin .NET).
2. Abre Godot, pulsa "Importar" y elige `project.godot` de esta carpeta.
3. Espera a que termine de importar y presiona F5 (Ejecutar).

La primera vez que se abre en el editor, Godot registra las clases del proyecto; no ejecutes
con `--path` sin haber abierto el proyecto una vez.

## Tienda pública
- Catálogo por categorías, buscador, orden, filtro de precio y de disponibilidad.
- Ficha de producto con galería, descripción, detalles, ficha técnica, tallas o tonos (con muestra de color) y existencias.
- Carrito con cantidades, totales automáticos y envío gratis desde $250.000 COP (si no, $12.000 COP).
- Checkout con validación; el pedido descuenta inventario y queda registrado.

## Panel de administración
Entra desde el enlace "Administración" al final de la tienda.
Contraseña inicial: `glowup2026` (cámbiala en Ajustes).

- Productos: agregar, editar, eliminar, ocultar, subir fotografías, actualizar precios.
- Inventario: existencias por talla o tono.
- Pedidos: cambiar estado (Pendiente, Confirmado, Enviado, Entregado, Cancelado). Cancelar devuelve el stock.
- Ventas: registrar ventas de tienda física.
- Estadísticas: ingresos, pedidos, ticket promedio, ventas de 7 días, por categoría, más vendidos y alertas de stock bajo.
- Ajustes: contraseña y base de datos compartida.

Los cambios se reflejan al instante en la tienda pública.

## Fotografías
Cada producto acepta varias fotos (una por línea): archivos subidos o URLs https.
Si una no carga, se prueba la siguiente; si ninguna está disponible, se muestra una imagen de respaldo.
Los productos de ejemplo usan imágenes de respaldo: sube tus fotos reales desde el panel.

## Base de datos compartida
- Por defecto: archivo JSON local (`user://glowup_db.json`).
- Para compartir entre dispositivos: en Ajustes indica la URL de un servicio REST que acepte GET y PUT
  de un documento JSON. La app sincroniza cada 20 segundos (gana el cambio más reciente).
- Para que las fotos se vean en todos los dispositivos, usa URLs https en lugar de archivos locales.

## Seguridad
La contraseña de administración se valida dentro de la propia aplicación, así que sirve para un
uso interno o de una sola tienda. Para una publicación abierta al público se recomienda un servidor
propio con autenticación real.

## Estructura
- `scripts/database.gd`: productos, inventario, pedidos, estadísticas y sincronización.
- `scripts/cart.gd`: carrito.
- `scripts/main.gd`: tienda, carrito y checkout.
- `scripts/admin_panel.gd`: panel de administración.
- `scripts/ui.gd`, `util.gd`, `product_image.gd`: tema, formato COP e imágenes.
